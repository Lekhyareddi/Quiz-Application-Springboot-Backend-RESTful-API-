package com.Project.quizApp.service;

import com.Project.quizApp.dao.QuestionDAO;
import com.Project.quizApp.dao.QuizDAO;
import com.Project.quizApp.model.Question;
import com.Project.quizApp.model.QuestionWrapper;
import com.Project.quizApp.model.Quiz;
import com.Project.quizApp.model.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class QuizService {

    @Autowired
    QuizDAO quizDAO;
    @Autowired
    QuestionDAO questionDAO;

   //this method is creating the quiz with 5 questions
    public ResponseEntity<String> createQuiz(String category,int numQ,String title) {

        //Generated the random question and below we have created the object for it and the set the title and the Id is auto generated and we saved the quiz.
        List<Question> question= questionDAO.fintRandomQuestionsByCategory(category,numQ);

        //create a quiz
        Quiz quiz=new Quiz();
        quiz.setTitle(title);
        quiz.setQuestion(question);
        quizDAO.save(quiz);
        return new ResponseEntity<>("Success", HttpStatus.CREATED);
    }

    public ResponseEntity<List<QuestionWrapper>> getQuizQuestions(int id) {
        //If the id is not present in the Database we will get NullPointerException
        // to handle that we will use the Optional
        Optional<Quiz> quiz=quizDAO.findById(id);
        List<Question> questionsFromDB= quiz.get().getQuestion();
        List<QuestionWrapper> questionsforUser = new ArrayList<>();
        for(Question q: questionsFromDB)
        {
            QuestionWrapper qw=new QuestionWrapper(q.getId(),q.getCategory(),q.getDifficultyLevel(),q.getOption1(),q.getOption2(),q.getOption3(),q.getQuestion());
            questionsforUser.add(qw);
        }
        return new ResponseEntity<>(questionsforUser,HttpStatus.OK);
    }

    public ResponseEntity<Integer> calculateResult(Integer id,List<Response> responses)
    {
        Optional<Quiz> quiz=quizDAO.findById(id);
       List<Question> questions=quiz.get().getQuestion();
       int right = 0;
       int i=0;
       for(Response response : responses)
       {
         if(response.getResponse().equals(questions.get(i).getRightAns()))
         {
             right++;
             i++;
         }
       }
       return new ResponseEntity<>(right,HttpStatus.OK);
    }
}
